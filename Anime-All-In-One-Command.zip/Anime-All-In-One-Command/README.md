# Anime All In One Command

A modular, interactive Bash toolkit for Ubuntu, Debian, and AlmaLinux.

## Install

```bash
git clone https://github.com/USERNAME/Anime-All-In-One-Command.git
cd Anime-All-In-One-Command
sudo bash install.sh
```

Or, after publishing the repository (replace `USERNAME`):

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/USERNAME/Anime-All-In-One-Command/main/install.sh)
```

The installer downloads no third-party scripts. It installs this project under `/opt/anime-all-cmd` and creates the `anime-all` launcher.

## Launch

```bash
anime-all
```

## Included modules

- VPS overview and basic management
- Pterodactyl Panel/Wings status and guided setup notes
- Docker status, installation, and container listing
- Minecraft server directory, Java check, and backup helper
- Discord bot systemd service helper
- CPU, RAM, disk, and uptime monitor
- Network diagnostics
- Security audit, firewall status, and optional UFW setup
- OS package updates

## Supported systems

- Ubuntu 20.04+
- Debian 11+
- AlmaLinux 8+

Run as root or through `sudo` for administrative actions. Read each confirmation prompt before proceeding.

## Safety notes

- Destructive operations require confirmation.
- The tool does not delete Docker containers, servers, or backups.
- It does not silently change SSH settings, open ports, or disable security controls.
- Pterodactyl installation is intentionally guided rather than piping an unverified remote installer into a root shell. Follow the official Pterodactyl documentation and review commands before running them.
- Backups are local archives; copy them to separate storage for disaster recovery.

## Repository layout

```text
.
├── install.sh
├── main.sh
├── config/settings.sh
├── assets/banner.sh
└── modules/
    ├── common.sh
    ├── vps.sh
    ├── pterodactyl.sh
    ├── docker.sh
    ├── minecraft.sh
    ├── discord.sh
    ├── monitor.sh
    ├── network.sh
    ├── security.sh
    └── update.sh
```

## Customize

Edit `config/settings.sh` to change the project name, install path, and backup location. Add new functionality as separate scripts under `modules/`.
