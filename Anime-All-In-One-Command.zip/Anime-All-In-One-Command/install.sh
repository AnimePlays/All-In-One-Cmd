#!/usr/bin/env bash
set -Eeuo pipefail

REPO_URL="${ANIME_CLOUD_REPO_URL:-}"
INSTALL_DIR="/opt/anime-all-cmd"
BIN_PATH="/usr/local/bin/anime-all"
TMP_DIR=""

cleanup() { [[ -n "${TMP_DIR}" && -d "${TMP_DIR}" ]] && rm -rf -- "${TMP_DIR}"; }
trap cleanup EXIT

if [[ "${EUID}" -ne 0 ]]; then
  echo "Please run: sudo bash install.sh"
  exit 1
fi

if [[ -f "$(dirname "$(readlink -f "$0")")/main.sh" ]]; then
  SOURCE_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
else
  if [[ -z "$REPO_URL" ]]; then
    echo "Could not find project files. Clone the repository or set ANIME_CLOUD_REPO_URL."
    exit 1
  fi
  command -v git >/dev/null || { echo "Git is required to fetch the project."; exit 1; }
  TMP_DIR="$(mktemp -d)"
  git clone --depth 1 "$REPO_URL" "$TMP_DIR/project"
  SOURCE_DIR="$TMP_DIR/project"
fi

[[ -f "$SOURCE_DIR/main.sh" ]] || { echo "main.sh not found."; exit 1; }
mkdir -p "$INSTALL_DIR"
cp -a "$SOURCE_DIR/." "$INSTALL_DIR/"
chmod 755 "$INSTALL_DIR/main.sh" "$INSTALL_DIR/modules/"*.sh
chmod 644 "$INSTALL_DIR/config/"*.sh "$INSTALL_DIR/assets/"*.sh 2>/dev/null || true

cat > "$BIN_PATH" <<'LAUNCHER'
#!/usr/bin/env bash
exec bash /opt/anime-all-cmd/main.sh "$@"
LAUNCHER
chmod 755 "$BIN_PATH"

echo
echo "Anime Cloud CMD installed successfully."
echo "Run: anime-all"
