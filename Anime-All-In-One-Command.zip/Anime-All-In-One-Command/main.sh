#!/usr/bin/env bash
set -Eeuo pipefail
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source= config/settings.sh
source "$BASE_DIR/config/settings.sh"
source "$BASE_DIR/modules/common.sh"
source "$BASE_DIR/assets/banner.sh"

for module in vps pterodactyl docker minecraft discord monitor network security update; do
  # shellcheck disable=SC1090
  source "$BASE_DIR/modules/${module}.sh"
done

while true; do
  clear 2>/dev/null || true
  ac_banner
  printf "${CYAN}  1)${RESET} VPS Manager                 ${CYAN}  2)${RESET} Pterodactyl Panel & Wings\n"
  printf "${CYAN}  3)${RESET} Docker Manager              ${CYAN}  4)${RESET} Minecraft Tools\n"
  printf "${CYAN}  5)${RESET} Discord Bot Manager         ${CYAN}  6)${RESET} System Monitor\n"
  printf "${CYAN}  7)${RESET} Network Tools               ${CYAN}  8)${RESET} Security & Backup\n"
  printf "${CYAN}  9)${RESET} Auto Update                 ${CYAN}  0)${RESET} Exit\n"
  echo
  read -rp "  Select an option: " choice
  case "$choice" in
    1) vps_menu ;;
    2) ptero_menu ;;
    3) docker_menu ;;
    4) minecraft_menu ;;
    5) discord_menu ;;
    6) monitor_menu ;;
    7) network_menu ;;
    8) security_menu ;;
    9) update_menu ;;
    0) echo "Anime All In One Command closed."; exit 0 ;;
    *) warn "Invalid option." ; pause ;;
  esac
done
