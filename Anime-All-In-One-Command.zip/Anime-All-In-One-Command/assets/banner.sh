#!/usr/bin/env bash
ac_banner() {
  echo -e "${CYAN}"
  cat <<'BANNER'
#
#
#                     █
#       ██
#       ██
#      ▒██▒  █▒██▒  ███    ██▓█▓   ███
#      ▓▒▒▓  █▓ ▒█    █    █▒█▒█  ▓▓ ▒█
#      █░░█  █   █    █    █ █ █  █   █
#      █  █  █   █    █    █ █ █  █████
#     ▒████▒ █   █    █    █ █ █  █
#     ▓▒  ▒▓ █   █    █    █ █ █  ▓▓  █
#     █░  ░█ █   █  █████  █ █ █   ███▒
#
#
#
BANNER
  echo -e "${RESET}  ${WHITE}Anime All In One Command${RESET} ${DIM}v1.0.0 | Ubuntu • Debian • AlmaLinux${RESET}"
  echo -e "${DIM}  ─────────────────────────────────────────────────────────${RESET}"
}
