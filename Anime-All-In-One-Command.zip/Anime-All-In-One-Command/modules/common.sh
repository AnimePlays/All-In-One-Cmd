#!/usr/bin/env bash
if [[ "${AC_COLOR:-yes}" == "yes" && -t 1 ]]; then
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
  CYAN='\033[0;36m'; WHITE='\033[1;37m'; DIM='\033[2m'; RESET='\033[0m'
else
  RED=''; GREEN=''; YELLOW=''; CYAN=''; WHITE=''; DIM=''; RESET=''
fi
info() { echo -e "${CYAN}[INFO]${RESET} $*"; }
ok() { echo -e "${GREEN}[ OK ]${RESET} $*"; }
warn() { echo -e "${YELLOW}[WARN]${RESET} $*"; }
err() { echo -e "${RED}[ERR ]${RESET} $*" >&2; }
pause() { read -rp "Press Enter to continue..." _; }
confirm() {
  local answer
  read -rp "${1:-Are you sure?} [y/N]: " answer
  [[ "$answer" =~ ^([yY]|[yY][eE][sS])$ ]]
}
require_root() {
  if [[ "${EUID}" -ne 0 ]]; then err "Run this action as root (sudo anime-cloud)."; return 1; fi
}
detect_os() {
  [[ -r /etc/os-release ]] && . /etc/os-release
  echo "${ID:-unknown}"
}
pkg_install() {
  local pkg="$1"
  case "$(detect_os)" in
    ubuntu|debian) apt-get update && apt-get install -y "$pkg" ;;
    almalinux|rhel|rocky|centos) dnf install -y "$pkg" ;;
    *) err "Unsupported distribution."; return 1 ;;
  esac
}
show_menu_header() { echo; echo -e "${WHITE}--- $1 ---${RESET}"; }
