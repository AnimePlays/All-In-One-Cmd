#!/usr/bin/env bash
docker_menu() {
  while true; do
    show_menu_header "Docker Manager"
    echo "1) Docker status   2) List containers   3) Install distribution Docker package"
    echo "4) Show disk usage 5) Start Docker service   0) Back"
    read -rp "Select: " c
    case "$c" in
      1) if command -v docker >/dev/null; then docker version --format 'Client: {{.Client.Version}}' 2>/dev/null; systemctl is-active docker 2>/dev/null || true; else warn "Docker is not installed."; fi; pause ;;
      2) if command -v docker >/dev/null; then docker ps -a; else warn "Docker is not installed."; fi; pause ;;
      3) if require_root && confirm "Install Docker from this distribution's package repositories?"; then pkg_install docker || pkg_install docker.io; fi; pause ;;
      4) if command -v docker >/dev/null; then docker system df; else warn "Docker is not installed."; fi; pause ;;
      5) if require_root; then systemctl enable --now docker && ok "Docker service started."; fi; pause ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
