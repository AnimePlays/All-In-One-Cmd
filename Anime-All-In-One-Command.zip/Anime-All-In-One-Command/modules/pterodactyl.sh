#!/usr/bin/env bash
ptero_menu() {
  while true; do
    show_menu_header "Pterodactyl Panel & Wings"
    echo "1) Check Panel service   2) Check Wings service"
    echo "3) Show common ports     4) Guided installation notes"
    echo "0) Back"
    read -rp "Select: " c
    case "$c" in
      1) systemctl status nginx --no-pager 2>/dev/null | head -18 || warn "Nginx service not found."; pause ;;
      2) systemctl status wings --no-pager 2>/dev/null | head -18 || warn "Wings service not found."; pause ;;
      3) echo "Typical defaults: Panel HTTP/HTTPS 80/443; Wings API commonly 8080; SFTP commonly 2022."; echo "Confirm your own panel configuration before changing firewall rules."; pause ;;
      4)
        echo "Guided setup:"
        echo "  1. Review the official documentation: https://pterodactyl.io/"
        echo "  2. Prepare a supported Linux server, DNS, and TLS."
        echo "  3. Install required dependencies using the official guide."
        echo "  4. Configure the Panel, database, queue worker, and web server."
        echo "  5. Install and configure Wings; verify the node configuration."
        echo "This tool does not run an unverified third-party root installer."
        pause ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
