#!/usr/bin/env bash
vps_overview() {
  show_menu_header "VPS Overview"
  printf "Hostname : "; hostname
  printf "OS       : "; . /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-Unknown}"
  printf "Kernel   : "; uname -r
  printf "Uptime   : "; uptime -p 2>/dev/null || uptime
  printf "IPv4     : "; hostname -I 2>/dev/null | awk '{print $1}'
  printf "CPU      : "; (command -v lscpu >/dev/null && lscpu | awk -F: '/Model name/ {gsub(/^ +/,"",$2); print $2; exit}') || echo "Unavailable"
  printf "Memory   : "; free -h 2>/dev/null | awk '/Mem:/ {print $3 " used / " $2 " total"}'
  printf "Root disk: "; df -h / | awk 'NR==2 {print $3 " used / " $2 " (" $5 ")"}'
}
vps_menu() {
  while true; do
    show_menu_header "VPS Manager"
    echo "1) Overview   2) Reboot VPS   3) Shutdown VPS   0) Back"
    read -rp "Select: " c
    case "$c" in
      1) vps_overview; pause ;;
      2) if require_root && confirm "Schedule an immediate reboot?"; then systemctl reboot; fi ;;
      3) if require_root && confirm "Shut down this VPS now?"; then systemctl poweroff; fi ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
