#!/usr/bin/env bash
minecraft_menu() {
  while true; do
    show_menu_header "Minecraft Tools"
    echo "1) Check Java   2) List configured server directory"
    echo "3) Create server backup   4) Show Minecraft-related processes   0) Back"
    read -rp "Select: " c
    case "$c" in
      1) java -version 2>&1 || warn "Java is not installed."; pause ;;
      2) echo "Directory: ${AC_MINECRAFT_DIR}"; if [[ -d "$AC_MINECRAFT_DIR" ]]; then ls -lah "$AC_MINECRAFT_DIR"; else warn "Directory does not exist. Change AC_MINECRAFT_DIR in config/settings.sh."; fi; pause ;;
      3)
        read -rp "Enter the full server directory to back up: " src
        if [[ -d "$src" && "$src" != "/" ]]; then
          mkdir -p "$AC_BACKUP_DIR"
          dest="$AC_BACKUP_DIR/minecraft-$(date +%Y%m%d-%H%M%S).tar.gz"
          if confirm "Create archive $dest from $src?"; then tar -czf "$dest" -C "$(dirname "$src")" "$(basename "$src")" && ok "Backup created: $dest"; fi
        else err "Directory not found or unsafe."; fi
        pause ;;
      4) pgrep -af 'java.*(server|paper|spigot|fabric|forge)' || true; pause ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
