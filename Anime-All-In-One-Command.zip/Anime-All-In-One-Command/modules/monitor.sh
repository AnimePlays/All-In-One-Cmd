#!/usr/bin/env bash
monitor_menu() {
  show_menu_header "System Monitor"
  echo "Load average: $(awk '{print $1, $2, $3}' /proc/loadavg)"
  echo
  free -h
  echo
  df -hT
  echo
  echo "Top processes:"
  ps -eo pid,comm,%cpu,%mem --sort=-%cpu | head -11
  pause
}
