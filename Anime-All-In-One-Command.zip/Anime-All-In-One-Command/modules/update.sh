#!/usr/bin/env bash
update_menu() {
  show_menu_header "Auto Update"
  echo "This updates system packages using the OS package manager."
  if ! require_root; then pause; return; fi
  if confirm "Proceed with package index refresh and upgrades?"; then
    case "$(detect_os)" in
      ubuntu|debian) apt-get update && apt-get upgrade ;;
      almalinux|rhel|rocky|centos) dnf upgrade ;;
      *) err "Unsupported operating system."; pause; return ;;
    esac
    ok "Package update command finished."
  fi
  pause
}
