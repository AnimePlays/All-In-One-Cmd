#!/usr/bin/env bash
network_menu() {
  while true; do
    show_menu_header "Network Tools"
    echo "1) IP addresses   2) Routes   3) DNS lookup   4) Ping test   5) Listening ports   0) Back"
    read -rp "Select: " c
    case "$c" in
      1) ip -brief address 2>/dev/null || hostname -I; pause ;;
      2) ip route 2>/dev/null || route -n; pause ;;
      3) read -rp "Hostname: " host; [[ "$host" =~ ^[a-zA-Z0-9.-]+$ ]] && (getent ahosts "$host" || true) || err "Invalid hostname."; pause ;;
      4) read -rp "Host to ping: " host; [[ "$host" =~ ^[a-zA-Z0-9.-]+$ ]] && ping -c 4 -W 2 "$host" || err "Invalid host or ping failed."; pause ;;
      5) ss -tulpen 2>/dev/null || ss -tulpn; pause ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
