#!/usr/bin/env bash
security_menu() {
  while true; do
    show_menu_header "Security & Backup"
    echo "1) Basic security audit   2) Firewall status"
    echo "3) Enable UFW (Ubuntu/Debian only)   4) Backup configuration files   0) Back"
    read -rp "Select: " c
    case "$c" in
      1)
        echo "SSH password authentication setting:"
        sshd -T 2>/dev/null | grep -E '^(permitrootlogin|passwordauthentication|pubkeyauthentication) ' || echo "sshd config unavailable"
        echo
        echo "Failed login summary:"
        (command -v journalctl >/dev/null && journalctl -u ssh -u sshd --since '24 hours ago' --no-pager 2>/dev/null | grep -ci 'failed' ) || true
        echo "Updates available (if supported):"
        if command -v apt-get >/dev/null; then apt list --upgradable 2>/dev/null | tail -n +2 | wc -l; elif command -v dnf >/dev/null; then dnf -q check-update 2>/dev/null | wc -l; fi
        pause ;;
      2) if command -v ufw >/dev/null; then ufw status verbose; elif command -v firewall-cmd >/dev/null; then firewall-cmd --state; firewall-cmd --list-all; else warn "No supported firewall frontend found."; fi; pause ;;
      3)
        if [[ "$(detect_os)" != "ubuntu" && "$(detect_os)" != "debian" ]]; then warn "This helper is for Ubuntu/Debian only; AlmaLinux commonly uses firewalld."; pause; continue; fi
        require_root || { pause; continue; }
        warn "Before enabling UFW, ensure your SSH port is allowed to avoid losing remote access."
        if confirm "Install UFW if needed, allow OpenSSH, then enable UFW?"; then
          command -v ufw >/dev/null || pkg_install ufw
          ufw allow OpenSSH
          ufw --force enable
          ufw status verbose
        fi
        pause ;;
      4)
        require_root || { pause; continue; }
        mkdir -p "$AC_BACKUP_DIR"
        dest="$AC_BACKUP_DIR/etc-config-$(date +%Y%m%d-%H%M%S).tar.gz"
        if confirm "Archive /etc/ssh and /etc/fstab to $dest?"; then
          tar -czf "$dest" -C / etc/ssh etc/fstab && ok "Saved $dest"
        fi
        pause ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
