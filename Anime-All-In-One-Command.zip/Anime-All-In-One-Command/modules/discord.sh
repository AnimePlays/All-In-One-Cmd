#!/usr/bin/env bash
discord_menu() {
  while true; do
    show_menu_header "Discord Bot Manager"
    echo "1) Check Node.js   2) List Anime Cloud bot services"
    echo "3) Install a bot as a systemd service   0) Back"
    read -rp "Select: " c
    case "$c" in
      1) node --version 2>/dev/null || warn "Node.js not found."; npm --version 2>/dev/null || true; pause ;;
      2) systemctl list-units --type=service --all --no-legend 'anime-bot-*' 2>/dev/null || true; pause ;;
      3)
        require_root || { pause; continue; }
        read -rp "Service name suffix (letters, numbers, hyphen): " suffix
        [[ "$suffix" =~ ^[a-zA-Z0-9-]+$ ]] || { err "Invalid service suffix."; pause; continue; }
        read -rp "Absolute path to bot entry file (e.g. /opt/mybot/index.js): " entry
        [[ "$entry" = /* && -f "$entry" ]] || { err "Entry file not found."; pause; continue; }
        command -v node >/dev/null || { err "Node.js is required."; pause; continue; }
        service="anime-bot-${suffix}"
        if confirm "Create and enable ${service}.service for ${entry}?"; then
          cat > "/etc/systemd/system/${service}.service" <<UNIT
[Unit]
Description=Anime Cloud Discord Bot (${suffix})
After=network.target

[Service]
Type=simple
WorkingDirectory=$(dirname "$entry")
ExecStart=$(command -v node) $entry
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
UNIT
          chmod 644 "/etc/systemd/system/${service}.service"
          systemctl daemon-reload
          systemctl enable --now "${service}.service"
          ok "Service installed. View logs: journalctl -u ${service} -f"
        fi
        pause ;;
      0) return ;;
      *) warn "Invalid option." ;;
    esac
  done
}
