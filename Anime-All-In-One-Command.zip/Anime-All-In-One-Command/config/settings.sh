#!/usr/bin/env bash
AC_NAME="Anime Cloud CMD"
AC_VERSION="1.0.0"
AC_BACKUP_DIR="/var/backups/anime-cloud"
AC_MINECRAFT_DIR="/opt/minecraft"
AC_COLOR="yes"
